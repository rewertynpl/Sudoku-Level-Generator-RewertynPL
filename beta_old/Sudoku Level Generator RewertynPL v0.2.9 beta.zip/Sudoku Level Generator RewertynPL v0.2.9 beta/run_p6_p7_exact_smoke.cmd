@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
set "REPO=%CD%"
set "EXE=%REPO%\sudoku_gen_test.exe"
set "REPORT_DIR=%REPO%\Debugs\smoke_reports"
set "SESSION_LOG=%REPORT_DIR%\p6_p7_exact_smoke_session.txt"
set "MAX_TOTAL_TIME=300"
set "MAX_ATTEMPTS=0"

if not exist "%REPORT_DIR%" mkdir "%REPORT_DIR%"
break > "%SESSION_LOG%"

net session >nul 2>&1
if errorlevel 1 (
    echo [ERROR] This smoke launcher must be run from an elevated CMD session.
    exit /b 1
)

where appverif.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] appverif.exe was not found in PATH.
    exit /b 1
)

call "%REPO%\kompilacja.bat" --no-pause
if errorlevel 1 exit /b 1

if not exist "%EXE%" (
    echo [ERROR] Missing binary: "%EXE%"
    exit /b 1
)

echo [INFO] Enabling AppVerifier for sudoku_gen_test.exe
>> "%SESSION_LOG%" echo [INFO] Enabling AppVerifier for sudoku_gen_test.exe
appverif.exe /verify "%EXE%"
if errorlevel 1 (
    echo [ERROR] Failed to enable AppVerifier.
    >> "%SESSION_LOG%" echo [ERROR] Failed to enable AppVerifier.
    exit /b 1
)

call :run_checked medusa3d 3 3 7 p7 nofast primary
call :run_checked medusa3d 4 3 7 p7 nofast asymmetric
call :run_checked aic 3 3 7 p7 nofast primary
call :run_checked aic 4 3 7 p7 nofast asymmetric
call :run_checked groupedaic 3 3 7 p7 nofast primary
call :run_checked groupedaic 4 3 7 p7 nofast asymmetric
call :run_checked groupedxcycle 3 3 7 p7 nofast primary
call :run_checked groupedxcycle 4 3 7 p7 nofast asymmetric
call :run_checked continuousniceloop 3 3 7 p7 nofast primary
call :run_checked continuousniceloop 4 3 7 p7 nofast asymmetric
call :run_checked alsxywing 3 3 7 p7 nofast primary
call :run_checked alsxywing 4 3 7 p7 nofast asymmetric
call :run_checked alschain 3 3 7 p7 nofast primary
call :run_checked alschain 4 3 7 p7 nofast asymmetric
call :run_checked suedecoq 3 3 7 p7 nofast primary
call :run_checked suedecoq 4 3 7 p7 nofast asymmetric
call :run_checked deathblossom 3 3 7 p7 nofast primary
call :run_checked deathblossom 4 3 7 p7 nofast asymmetric
call :run_checked frankenfish 3 3 7 p7 nofast primary
call :run_checked frankenfish 4 3 7 p7 nofast asymmetric
call :run_checked mutantfish 3 3 7 p7 nofast primary
call :run_checked mutantfish 4 3 7 p7 nofast asymmetric
call :run_checked krakenfish 3 3 7 p7 nofast primary
call :run_checked krakenfish 4 3 7 p7 nofast asymmetric
call :run_checked squirmbag 3 3 7 p7 nofast primary
call :run_checked squirmbag 4 3 7 p7 nofast asymmetric
call :run_checked alignedpairexclusion 3 3 7 p7 nofast primary
call :run_checked alignedpairexclusion 4 3 7 p7 nofast asymmetric
call :run_checked alignedtripleexclusion 3 3 7 p7 nofast primary
call :run_checked alignedtripleexclusion 4 3 7 p7 nofast asymmetric
call :run_checked alsaic 3 3 7 p7 nofast primary
call :run_checked alsaic 4 3 7 p7 nofast asymmetric

call :run_checked msls 3 3 8 p8 nofast primary
call :run_checked msls 4 3 8 p8 nofast asymmetric
call :run_checked exocet 3 3 8 p8 nofast primary
call :run_checked exocet 4 3 8 p8 nofast asymmetric
call :run_checked seniorexocet 3 3 8 p8 nofast primary
call :run_checked seniorexocet 4 3 8 p8 nofast asymmetric
call :run_checked skloop 3 3 8 p8 nofast primary
call :run_checked skloop 4 3 8 p8 nofast asymmetric
call :run_checked patternoverlaymethod 3 3 8 p8 nofast primary
call :run_checked patternoverlaymethod 4 3 8 p8 nofast asymmetric
call :run_checked forcingchains 3 3 8 p8 nofast primary
call :run_checked forcingchains 4 3 8 p8 nofast asymmetric
call :run_checked dynamicforcingchains 3 3 8 p8 nofast primary
call :run_checked dynamicforcingchains 4 3 8 p8 nofast asymmetric

goto cleanup_ok

:cleanup_fail
echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
>> "%SESSION_LOG%" echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
appverif.exe /n "%EXE%" >nul 2>&1
exit /b 1

:cleanup_ok
echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
>> "%SESSION_LOG%" echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
appverif.exe /n "%EXE%" >nul 2>&1

echo [DONE] Smoke sequence finished.
>> "%SESSION_LOG%" echo [DONE] Smoke sequence finished.
exit /b 0

:run_strategy
set "STRATEGY=%~1"
set "BOX_ROWS=%~2"
set "BOX_COLS=%~3"
set "DIFFICULTY=%~4"
set "MCTS_PROFILE=%~5"
set "FAST_MODE=%~6"
set "VARIANT=%~7"
set "OUTDIR=Debugs\smoke_%STRATEGY%_%VARIANT%"
set "RUNLOG=%REPORT_DIR%\%STRATEGY%_%VARIANT%_raw.txt"

echo.
echo ============================================================================
echo [SMOKE] %STRATEGY% [%VARIANT%] geom=%BOX_ROWS%x%BOX_COLS% difficulty=%DIFFICULTY%
echo ============================================================================
>> "%SESSION_LOG%" echo.
>> "%SESSION_LOG%" echo ============================================================================
>> "%SESSION_LOG%" echo [SMOKE] %STRATEGY% [%VARIANT%] geom=%BOX_ROWS%x%BOX_COLS% difficulty=%DIFFICULTY%
>> "%SESSION_LOG%" echo ============================================================================

if /I "%FAST_MODE%"=="nofast" (
    "%EXE%" --cli --box-rows %BOX_ROWS% --box-cols %BOX_COLS% --difficulty %DIFFICULTY% --required-strategy %STRATEGY% --seed 0 --target 5 --threads 12 --max-total-time-s %MAX_TOTAL_TIME% --max-attempts %MAX_ATTEMPTS% --mcts-profile %MCTS_PROFILE% --output-folder "%OUTDIR%" --output-file generated_sudoku.txt --single-file-only --benchmark-mode --pattern-forcing --strict-canonical-strategies --no-proxy-advanced --no-fast-test > "%RUNLOG%" 2>&1
) else (
    "%EXE%" --cli --box-rows %BOX_ROWS% --box-cols %BOX_COLS% --difficulty %DIFFICULTY% --required-strategy %STRATEGY% --seed 0 --target 5 --threads 12 --max-total-time-s %MAX_TOTAL_TIME% --max-attempts %MAX_ATTEMPTS% --mcts-profile %MCTS_PROFILE% --output-folder "%OUTDIR%" --output-file generated_sudoku.txt --single-file-only --benchmark-mode --pattern-forcing --strict-canonical-strategies --no-proxy-advanced --fast-test > "%RUNLOG%" 2>&1
)
set "RUN_EXIT=%ERRORLEVEL%"
type "%RUNLOG%"
type "%RUNLOG%" >> "%SESSION_LOG%"
if not "%RUN_EXIT%"=="0" (
    echo [ERROR] Strategy failed: %STRATEGY% [%VARIANT%]
    >> "%SESSION_LOG%" echo [ERROR] Strategy failed: %STRATEGY% [%VARIANT%]
    goto cleanup_fail
)

goto :eof

:run_checked
call :run_strategy %*
if errorlevel 1 goto cleanup_fail
goto :eof
