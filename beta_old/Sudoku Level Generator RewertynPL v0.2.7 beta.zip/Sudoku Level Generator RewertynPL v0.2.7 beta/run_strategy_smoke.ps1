param(
    [string]$Strategy,
    [switch]$All,
    [switch]$SkipBuild,
    [switch]$SkipAppVerifier,
    [string]$QualityReport = "Debugs\\quality_benchmark_report.txt",
    [string]$ResultsCsv = "Debugs\\strategy_smoke_results.csv",
    [string]$ResultsDir = "Debugs\\smoke_reports",
    [int]$MemoryRepeats = 3,
    [UInt64]$MemoryGrowthThresholdMb = 64,
    [UInt64]$MaxTotalTimeOverrideSec = 0,
    [UInt64]$MaxAttemptsOverride = 0
)

$ErrorActionPreference = 'Stop'

function Normalize-Token {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return "" }
    return (($Value.ToCharArray() | Where-Object { [char]::IsLetterOrDigit($_) }) -join "").ToLowerInvariant()
}

function ConvertTo-BoolFlag {
    param($Value)
    return "$Value" -in @("1", "true", "True", "TRUE")
}

function ConvertTo-UInt64Safe {
    param($Value)
    if ([string]::IsNullOrWhiteSpace("$Value")) { return [UInt64]0 }
    return [UInt64]::Parse("$Value")
}

function Invoke-LoggedProcess {
    param(
        [string]$FilePath,
        [string[]]$Arguments,
        [string]$WorkingDirectory
    )

    $quotedArgs = $Arguments | ForEach-Object {
        if ($_ -match '[\s"]') {
            '"' + ($_ -replace '"', '\"') + '"'
        } else {
            $_
        }
    }

    $psi = [System.Diagnostics.ProcessStartInfo]::new()
    $psi.FileName = $FilePath
    $psi.Arguments = ($quotedArgs -join ' ')
    $psi.WorkingDirectory = $WorkingDirectory
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $proc = [System.Diagnostics.Process]::Start($psi)
    $peakWorkingSet = [UInt64]0
    $peakPrivateBytes = [UInt64]0
    while (-not $proc.HasExited) {
        try {
            $peakWorkingSet = [Math]::Max($peakWorkingSet, [UInt64]$proc.WorkingSet64)
            $peakPrivateBytes = [Math]::Max($peakPrivateBytes, [UInt64]$proc.PrivateMemorySize64)
        } catch {
        }
        Start-Sleep -Milliseconds 200
    }

    $stdout = $proc.StandardOutput.ReadToEnd()
    $stderr = $proc.StandardError.ReadToEnd()
    try {
        $peakWorkingSet = [Math]::Max($peakWorkingSet, [UInt64]$proc.PeakWorkingSet64)
    } catch {
    }
    try {
        $peakPrivateBytes = [Math]::Max($peakPrivateBytes, [UInt64]$proc.PrivateMemorySize64)
    } catch {
    }

    return [pscustomobject]@{
        ExitCode = $proc.ExitCode
        StdOut = $stdout
        StdErr = $stderr
        PeakWorkingSet = $peakWorkingSet
        PeakPrivateBytes = $peakPrivateBytes
    }
}

function Parse-SmokeSummary {
    param([string]$Text)

    $patterns = @{
        accepted = 'Accepted:\s+(\d+)'
        attempts = 'Attempts:\s+(\d+)'
        prefilter = 'Prefilter:\s+(\d+)'
        logic = 'Logic:\s+(\d+)'
        written = 'Written:\s+(\d+)'
        seed_built = 'seed-built\s*=\s*(\d+)'
        seed_unsolved = 'seed-unsolved\s*=\s*(\d+)'
        seed_miss = 'seed-miss\s*=\s*(\d+)'
        strategy = 'Strategy:\s+(\d+)'
        mcts_required = 'MCTS required hit/use:\s+(\d+)/(\d+)'
        cert = 'Certifier required analyzed/use/hit:\s+(\d+)/(\d+)/(\d+)'
        exact = 'Pattern exact template used:\s+(\d+)'
        fallback = 'Pattern family fallback used:\s+(\d+)'
        exact_contract = 'Required exact contract met:\s+(\d+)'
        rate = 'Rate:\s+([0-9.]+)\s+puzzles/s'
    }

    $metrics = [ordered]@{
        Accepted = 0
        Attempts = 0
        Prefilter = 0
        Logic = 0
        Written = 0
        SeedBuilt = 0
        SeedUnsolved = 0
        SeedMiss = 0
        Strategy = 0
        MctsRequiredHit = 0
        MctsRequiredUse = 0
        CertifierAnalyzed = 0
        CertifierUse = 0
        CertifierHit = 0
        ExactTemplateUsed = 0
        FamilyFallbackUsed = 0
        ExactContractMet = 0
        AcceptedPerSec = 0.0
    }

    if ($Text -match $patterns.accepted) { $metrics.Accepted = [UInt64]$Matches[1] }
    if ($Text -match $patterns.attempts) { $metrics.Attempts = [UInt64]$Matches[1] }
    if ($Text -match $patterns.prefilter) { $metrics.Prefilter = [UInt64]$Matches[1] }
    if ($Text -match $patterns.logic) { $metrics.Logic = [UInt64]$Matches[1] }
    if ($Text -match $patterns.written) { $metrics.Written = [UInt64]$Matches[1] }
    if ($Text -match $patterns.seed_built) { $metrics.SeedBuilt = [UInt64]$Matches[1] }
    if ($Text -match $patterns.seed_unsolved) { $metrics.SeedUnsolved = [UInt64]$Matches[1] }
    if ($Text -match $patterns.seed_miss) { $metrics.SeedMiss = [UInt64]$Matches[1] }
    if ($Text -match $patterns.strategy) { $metrics.Strategy = [UInt64]$Matches[1] }
    if ($Text -match $patterns.mcts_required) {
        $metrics.MctsRequiredHit = [UInt64]$Matches[1]
        $metrics.MctsRequiredUse = [UInt64]$Matches[2]
    }
    if ($Text -match $patterns.cert) {
        $metrics.CertifierAnalyzed = [UInt64]$Matches[1]
        $metrics.CertifierUse = [UInt64]$Matches[2]
        $metrics.CertifierHit = [UInt64]$Matches[3]
    }
    if ($Text -match $patterns.exact) { $metrics.ExactTemplateUsed = [UInt64]$Matches[1] }
    if ($Text -match $patterns.fallback) { $metrics.FamilyFallbackUsed = [UInt64]$Matches[1] }
    if ($Text -match $patterns.exact_contract) { $metrics.ExactContractMet = [UInt64]$Matches[1] }
    if ($Text -match $patterns.rate) { $metrics.AcceptedPerSec = [double]::Parse($Matches[1], [System.Globalization.CultureInfo]::InvariantCulture) }

    return [pscustomobject]$metrics
}

function Write-SmokeReport {
    param(
        [string]$Path,
        $Row,
        [string]$VariantLabel,
        [string]$Prefix,
        [string[]]$CommandArgs,
        $Summary,
        [string]$StdOut,
        [string]$StdErr,
        [int]$ExitCode,
        [string]$AppVerifierStatus,
        [bool]$Pass,
        [UInt64[]]$PeakWorkingSetSamples,
        [UInt64[]]$PeakPrivateSamples,
        [double]$HitRate,
        [bool]$MemoryTrendFail,
        [UInt64]$MinUse,
        [UInt64]$MinHit,
        [bool]$ExactRequired
    )

    $reportDir = Split-Path -Parent $Path
    if (-not [string]::IsNullOrWhiteSpace($reportDir)) {
        New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
    }

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add(("Strategy: {0}" -f $Row.required_strategy))
    $lines.Add(("Variant: {0}" -f $VariantLabel))
    $lines.Add(("Pass: {0}" -f $Pass))
    $lines.Add(("ExitCode: {0}" -f $ExitCode))
    $lines.Add(("AppVerifier: {0}" -f $AppVerifierStatus))
    $lines.Add(("Command: sudoku_gen_test.exe {0}" -f ($CommandArgs -join ' ')))
    $lines.Add(("Required strategy use (certifier): {0}" -f $Summary.CertifierUse))
    $lines.Add(("Required strategy hit (certifier): {0}" -f $Summary.CertifierHit))
    $lines.Add(("Required strategy analyzed (certifier): {0}" -f $Summary.CertifierAnalyzed))
    $lines.Add(("Required strategy use/hit (certifier): {0}/{1}" -f $Summary.CertifierUse, $Summary.CertifierHit))
    $lines.Add(("MCTS required use/hit: {0}/{1}" -f $Summary.MctsRequiredUse, $Summary.MctsRequiredHit))
    $lines.Add(("Hit rate: {0}" -f ([Math]::Round($HitRate, 4).ToString([System.Globalization.CultureInfo]::InvariantCulture))))
    $lines.Add(("Accepted: {0}" -f $Summary.Accepted))
    $lines.Add(("Attempts: {0}" -f $Summary.Attempts))
    $lines.Add(("Prefilter: {0}" -f $Summary.Prefilter))
    $lines.Add(("Logic: {0}" -f $Summary.Logic))
    $lines.Add(("Written: {0}" -f $Summary.Written))
    $lines.Add(("seed-built = {0}" -f $Summary.SeedBuilt))
    $lines.Add(("seed-unsolved = {0}" -f $Summary.SeedUnsolved))
    $lines.Add(("seed-miss = {0}" -f $Summary.SeedMiss))
    $lines.Add(("Strategy-stage rejects: {0}" -f $Summary.Strategy))
    $lines.Add(("Certifier required analyzed/use/hit: {0}/{1}/{2}" -f $Summary.CertifierAnalyzed, $Summary.CertifierUse, $Summary.CertifierHit))
    $lines.Add(("Pattern exact template used: {0}" -f $Summary.ExactTemplateUsed))
    $lines.Add(("Pattern family fallback used: {0}" -f $Summary.FamilyFallbackUsed))
    $lines.Add(("Required exact contract met: {0}" -f $Summary.ExactContractMet))
    $lines.Add(("Accepted/sec: {0}" -f ([Math]::Round($Summary.AcceptedPerSec, 4).ToString([System.Globalization.CultureInfo]::InvariantCulture))))
    $lines.Add(("Min required use/hit: {0}/{1}" -f $MinUse, $MinHit))
    $lines.Add(("Exact contract required: {0}" -f $ExactRequired))
    $lines.Add(("Memory trend fail: {0}" -f $MemoryTrendFail))
    $lines.Add(("Peak working set MB samples: {0}" -f (($PeakWorkingSetSamples | ForEach-Object { [Math]::Round($_ / 1MB, 2).ToString([System.Globalization.CultureInfo]::InvariantCulture) }) -join ", ")))
    $lines.Add(("Peak private MB samples: {0}" -f (($PeakPrivateSamples | ForEach-Object { [Math]::Round($_ / 1MB, 2).ToString([System.Globalization.CultureInfo]::InvariantCulture) }) -join ", ")))
    $lines.Add("")
    $lines.Add("[StdOut]")
    $lines.Add($StdOut)
    $lines.Add("")
    $lines.Add("[StdErr]")
    $lines.Add($StdErr)

    Set-Content -LiteralPath $Path -Value $lines -Encoding UTF8
}

function Get-ProfileArgs {
    param(
        $Row,
        [string]$Prefix,
        [string]$OutputFolder,
        [UInt64]$MaxTotalTimeOverrideSec = 0,
        [UInt64]$MaxAttemptsOverride = 0
    )

    $maxTotalTime = if ($MaxTotalTimeOverrideSec -gt 0) {
        $MaxTotalTimeOverrideSec
    } else {
        $Row."${Prefix}_max_total_time_s"
    }
    $maxAttempts = if ($MaxAttemptsOverride -gt 0) {
        $MaxAttemptsOverride
    } else {
        $Row."${Prefix}_max_attempts"
    }

    $args = @(
        "--cli",
        "--box-rows", "$($Row."${Prefix}_box_rows")",
        "--box-cols", "$($Row."${Prefix}_box_cols")",
        "--difficulty", "$($Row."${Prefix}_difficulty")",
        "--required-strategy", "$($Row.required_strategy)",
        "--seed", "$($Row."${Prefix}_seed")",
        "--target", "1",
        "--threads", "1",
        "--max-total-time-s", "$maxTotalTime",
        "--max-attempts", "$maxAttempts",
        "--mcts-profile", "$($Row."${Prefix}_mcts_profile")",
        "--output-folder", $OutputFolder,
        "--output-file", "generated_sudoku.txt",
        "--single-file-only",
        "--benchmark-mode"
    )

    if ([int]$Row."${Prefix}_difficulty" -ge 8) {
        $args += "--no-fast-test"
    } else {
        $args += "--fast-test"
    }

    if (ConvertTo-BoolFlag $Row."${Prefix}_pattern_forcing") {
        $args += "--pattern-forcing"
    } else {
        $args += "--no-mcts-digger"
    }
    if (ConvertTo-BoolFlag $Row."${Prefix}_strict_canonical") {
        $args += "--strict-canonical-strategies"
    }
    if (ConvertTo-BoolFlag $Row."${Prefix}_allow_proxy") {
        $args += "--allow-proxy-advanced"
    } else {
        $args += "--no-proxy-advanced"
    }
    if (ConvertTo-BoolFlag $Row."${Prefix}_exact_contract_required") {
        $args += "--strict-logical"
    }

    return $args
}

function Configure-AppVerifier {
    param([string]$ExePath)
    if ($SkipAppVerifier) {
        throw "AppVerifier is mandatory for this smoke harness."
    }
    $appverif = Get-Command appverif.exe -ErrorAction Stop
    try {
        $null = & $appverif.Source /verify $ExePath /tests Basics
        if ($LASTEXITCODE -ne 0) {
            throw "appverif.exe returned exit code $LASTEXITCODE"
        }
        return "enabled"
    } catch {
        throw "Failed to enable AppVerifier: $($_.Exception.Message)"
    }
}

function Reset-AppVerifier {
    param([string]$ExePath)
    if ($SkipAppVerifier) { return }
    try {
        $null = & appverif.exe /n $ExePath
    } catch {
    }
}

$repoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $repoRoot

if (-not $All -and [string]::IsNullOrWhiteSpace($Strategy)) {
    throw "Use -Strategy <name> or -All."
}

& powershell -NoProfile -ExecutionPolicy Bypass -File "$repoRoot\audit_hpc_hotpath.ps1"
if ($LASTEXITCODE -ne 0) {
    throw "HPC hot-path audit failed."
}

if (-not $SkipBuild) {
    & cmd /c "`"$repoRoot\kompilacja.bat`" --no-pause"
    if ($LASTEXITCODE -ne 0) {
        throw "Build failed."
    }
}

$exePath = Join-Path $repoRoot "sudoku_gen_test.exe"
if (-not (Test-Path -LiteralPath $exePath)) {
    throw "Missing binary: $exePath"
}

$qualityReportRelative = $QualityReport
if ($QualityReport -eq "Debugs\\quality_benchmark_report.txt") {
    $token = if ($All) { "all" } else { Normalize-Token $Strategy }
    if ([string]::IsNullOrWhiteSpace($token)) {
        $token = "selection"
    }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
    $qualityReportRelative = "Debugs\\quality_benchmark_${token}_${stamp}.txt"
}

$qualityReportPath = Join-Path $repoRoot $qualityReportRelative
$qualityDir = Split-Path -Parent $qualityReportPath
if (-not [string]::IsNullOrWhiteSpace($qualityDir)) {
    New-Item -ItemType Directory -Force -Path $qualityDir | Out-Null
}

& $exePath --run-quality-benchmark $qualityReportPath
if ($LASTEXITCODE -ne 0) {
    throw "Failed to generate quality benchmark report."
}

$qualityCsvPath = [System.IO.Path]::ChangeExtension($qualityReportPath, ".csv")
if (-not (Test-Path -LiteralPath $qualityCsvPath)) {
    throw "Missing generated CSV report: $qualityCsvPath"
}

$reportRoot = Join-Path $repoRoot $ResultsDir
New-Item -ItemType Directory -Force -Path $reportRoot | Out-Null

$rows = Import-Csv -LiteralPath $qualityCsvPath
$selectedRows = if ($All) {
    $rows | Where-Object { ConvertTo-BoolFlag $_.smoke_profile_present }
} else {
    $wanted = Normalize-Token $Strategy
    $rows | Where-Object { (Normalize-Token $_.required_strategy) -eq $wanted }
}

if (-not $selectedRows -or $selectedRows.Count -eq 0) {
    throw "No smoke profile rows matched the requested strategy selection."
}

$results = New-Object System.Collections.Generic.List[object]
$appVerifierStatus = Configure-AppVerifier -ExePath $exePath

try {
    $runToken = Get-Date -Format "yyyyMMdd_HHmmss_fff"
    foreach ($row in $selectedRows) {
        $profileKinds = @("smoke_primary")
        if (ConvertTo-BoolFlag $row.smoke_asymmetric_present) {
            $profileKinds += "smoke_asymmetric"
        }

        foreach ($prefix in $profileKinds) {
            $variantLabel = $row."${prefix}_variant"
            if ([string]::IsNullOrWhiteSpace($variantLabel)) {
                continue
            }

            $peaksWs = New-Object System.Collections.Generic.List[UInt64]
            $peaksPm = New-Object System.Collections.Generic.List[UInt64]
            $lastSummary = $null
            $lastOutput = ""
            $lastError = ""
            $lastExitCode = 0

            for ($repeat = 1; $repeat -le [Math]::Max(1, $MemoryRepeats); ++$repeat) {
                $runDir = Join-Path $repoRoot ("Debugs\smoke_{0}_{1}_{2}_{3}" -f $row.required_strategy, $variantLabel, $repeat, $runToken)
                New-Item -ItemType Directory -Force -Path $runDir | Out-Null

    $cliArgs = Get-ProfileArgs `
        -Row $row `
        -Prefix $prefix `
        -OutputFolder $runDir `
        -MaxTotalTimeOverrideSec $MaxTotalTimeOverrideSec `
        -MaxAttemptsOverride $MaxAttemptsOverride
                $run = Invoke-LoggedProcess -FilePath $exePath -Arguments $cliArgs -WorkingDirectory $repoRoot
                $summary = Parse-SmokeSummary -Text ($run.StdOut + "`n" + $run.StdErr)

                $peaksWs.Add([UInt64]$run.PeakWorkingSet)
                $peaksPm.Add([UInt64]$run.PeakPrivateBytes)
                $lastSummary = $summary
                $lastOutput = $run.StdOut
                $lastError = $run.StdErr
                $lastExitCode = $run.ExitCode
            }

            $memoryTrendFail = $false
            $growthBytes = [Int64]0
            if ($peaksPm.Count -ge 3) {
                $rising = $true
                for ($i = 1; $i -lt $peaksPm.Count; ++$i) {
                    if ($peaksPm[$i] -lt $peaksPm[$i - 1]) {
                        $rising = $false
                        break
                    }
                }
                $growthBytes = [Int64]$peaksPm[$peaksPm.Count - 1] - [Int64]$peaksPm[0]
                if ($rising -and $growthBytes -gt ($MemoryGrowthThresholdMb * 1MB)) {
                    $memoryTrendFail = $true
                }
            }

            $minUse = ConvertTo-UInt64Safe $row."${prefix}_min_required_use"
            $minHit = ConvertTo-UInt64Safe $row."${prefix}_min_required_hit"
            $exactRequired = ConvertTo-BoolFlag $row."${prefix}_exact_contract_required"
            $pass =
                ($lastExitCode -eq 0) -and
                ($appVerifierStatus -eq "enabled") -and
                ($lastSummary.CertifierUse -ge $minUse) -and
                ($lastSummary.CertifierHit -ge $minHit) -and
                (-not $memoryTrendFail) -and
                (-not (($lastOutput + "`n" + $lastError) -match 'Fatal error'))
            if ($exactRequired -and $lastSummary.ExactContractMet -lt 1) {
                $pass = $false
            }
            if ($exactRequired -and $lastSummary.FamilyFallbackUsed -gt 0) {
                $pass = $false
            }

            $hitRate = 0.0
            if ($lastSummary.CertifierUse -gt 0) {
                $hitRate = [double]$lastSummary.CertifierHit / [double]$lastSummary.CertifierUse
            }

            $reportPath = Join-Path $reportRoot ("{0}_{1}.txt" -f $row.required_strategy, $variantLabel)
            Write-SmokeReport `
                -Path $reportPath `
                -Row $row `
                -VariantLabel $variantLabel `
                -Prefix $prefix `
                -CommandArgs $cliArgs `
                -Summary $lastSummary `
                -StdOut $lastOutput `
                -StdErr $lastError `
                -ExitCode $lastExitCode `
                -AppVerifierStatus $appVerifierStatus `
                -Pass $pass `
                -PeakWorkingSetSamples $peaksWs.ToArray() `
                -PeakPrivateSamples $peaksPm.ToArray() `
                -HitRate $hitRate `
                -MemoryTrendFail $memoryTrendFail `
                -MinUse $minUse `
                -MinHit $minHit `
                -ExactRequired $exactRequired

            $results.Add([pscustomobject]@{
                strategy = $row.required_strategy
                variant = $variantLabel
                pass = $pass
                required_strategy_use = $lastSummary.CertifierUse
                required_strategy_hit = $lastSummary.CertifierHit
                required_strategy_analyzed = $lastSummary.CertifierAnalyzed
                required_strategy_use_hit = ("{0}/{1}" -f $lastSummary.CertifierUse, $lastSummary.CertifierHit)
                mcts_required_use = $lastSummary.MctsRequiredUse
                mcts_required_hit = $lastSummary.MctsRequiredHit
                mcts_required_use_hit = ("{0}/{1}" -f $lastSummary.MctsRequiredUse, $lastSummary.MctsRequiredHit)
                appverif_status = $appVerifierStatus
                exit_code = $lastExitCode
                accepted = $lastSummary.Accepted
                attempts = $lastSummary.Attempts
                prefilter = $lastSummary.Prefilter
                logic = $lastSummary.Logic
                written = $lastSummary.Written
                certifier_required_analyzed = $lastSummary.CertifierAnalyzed
                certifier_required_use = $lastSummary.CertifierUse
                certifier_required_hit = $lastSummary.CertifierHit
                hit_rate = [Math]::Round($hitRate, 4)
                exact_template_used = $lastSummary.ExactTemplateUsed
                family_fallback_used = $lastSummary.FamilyFallbackUsed
                exact_contract_met = $lastSummary.ExactContractMet
                accepted_per_sec = [Math]::Round($lastSummary.AcceptedPerSec, 4)
                peak_working_set_mb = [Math]::Round(($peaksWs | Measure-Object -Maximum).Maximum / 1MB, 2)
                peak_private_bytes_mb = [Math]::Round(($peaksPm | Measure-Object -Maximum).Maximum / 1MB, 2)
                memory_growth_private_mb = if ($peaksPm.Count -ge 2) {
                    [Math]::Round(([Int64]$peaksPm[$peaksPm.Count - 1] - [Int64]$peaksPm[0]) / 1MB, 2)
                } else { 0.0 }
                memory_trend_fail = $memoryTrendFail
                seed_built = $lastSummary.SeedBuilt
                seed_unsolved = $lastSummary.SeedUnsolved
                seed_miss = $lastSummary.SeedMiss
                strategy_stage_rejects = $lastSummary.Strategy
                strategy_hits = $lastSummary.Strategy
                min_required_use = $minUse
                min_required_hit = $minHit
                exact_contract_required = $exactRequired
                detailed_report = $reportPath
            })
        }
    }
}
finally {
    Reset-AppVerifier -ExePath $exePath
}

$resultsPath = Join-Path $repoRoot $ResultsCsv
$resultsDir = Split-Path -Parent $resultsPath
if (-not [string]::IsNullOrWhiteSpace($resultsDir)) {
    New-Item -ItemType Directory -Force -Path $resultsDir | Out-Null
}
$results | Export-Csv -LiteralPath $resultsPath -NoTypeInformation -Encoding UTF8

$results |
    Select-Object `
        strategy,
        variant,
        pass,
        required_strategy_use,
        required_strategy_hit,
        required_strategy_analyzed,
        mcts_required_use,
        mcts_required_hit,
        accepted,
        attempts,
        prefilter,
        logic,
        strategy_stage_rejects,
        hit_rate,
        appverif_status |
    Format-Table -AutoSize
$failed = @($results | Where-Object { -not $_.pass })
if ($failed.Count -gt 0) {
    Write-Error "Smoke failures detected. Results: $resultsPath"
}

Write-Host "Smoke results: $resultsPath"
