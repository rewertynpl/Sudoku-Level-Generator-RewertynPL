param(
    [switch]$SkipBuild,
    [int]$MemoryRepeats = 1,
    [UInt64]$MaxTotalTimeOverrideSec = 300,
    [UInt64]$MaxAttemptsOverride = 0
)

$ErrorActionPreference = 'Stop'

$repoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $repoRoot

$strategies = @(
    'medusa3d',
    'aic',
    'groupedaic',
    'groupedxcycle',
    'continuousniceloop',
    'alsxywing',
    'alschain',
    'suedecoq',
    'deathblossom',
    'frankenfish',
    'mutantfish',
    'krakenfish',
    'squirmbag',
    'alignedpairexclusion',
    'alignedtripleexclusion',
    'alsaic',
    'msls',
    'exocet',
    'seniorexocet',
    'skloop',
    'patternoverlaymethod',
    'forcingchains',
    'dynamicforcingchains'
)

foreach ($strategy in $strategies) {
    Write-Host ("=== Smoke: {0} ===" -f $strategy)
    $args = @(
        '-ExecutionPolicy', 'Bypass',
        '-File', (Join-Path $repoRoot 'run_strategy_smoke.ps1'),
        '-Strategy', $strategy,
        '-MemoryRepeats', "$MemoryRepeats",
        '-MaxTotalTimeOverrideSec', "$MaxTotalTimeOverrideSec"
    )
    if ($SkipBuild) {
        $args += '-SkipBuild'
    }
    if ($MaxAttemptsOverride -gt 0) {
        $args += @('-MaxAttemptsOverride', "$MaxAttemptsOverride")
    }

    & powershell @args
    if ($LASTEXITCODE -ne 0) {
        throw ("Smoke failed for strategy: {0}" -f $strategy)
    }
}
