@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
set "REPO=%CD%"
set "EXE=%REPO%\sudoku_gen_test.exe"
set "REPORT_DIR=%REPO%\Debugs\smoke_reports"
set "SESSION_LOG=%REPORT_DIR%\p6_p7_exact_smoke_session.txt"
set "MAX_TOTAL_TIME=155"
set "MAX_ATTEMPTS=0"

if not exist "%REPORT_DIR%" mkdir "%REPORT_DIR%"
break > "%SESSION_LOG%"

net session >nul 2>&1
if errorlevel 1 (
    echo [ERROR] This smoke launcher must be run from an elevated CMD session.
    exit /b 1
)

where appverif.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] appverif.exe was not found in PATH.
    exit /b 1
)

call "%REPO%\kompilacja.bat" --no-pause
if errorlevel 1 exit /b 1

if not exist "%EXE%" (
    echo [ERROR] Missing binary: "%EXE%"
    exit /b 1
)

echo [INFO] Enabling AppVerifier for sudoku_gen_test.exe
>> "%SESSION_LOG%" echo [INFO] Enabling AppVerifier for sudoku_gen_test.exe
appverif.exe /verify "%EXE%"
if errorlevel 1 (
    echo [ERROR] Failed to enable AppVerifier.
    >> "%SESSION_LOG%" echo [ERROR] Failed to enable AppVerifier.
    exit /b 1
)

for %%L in (
    "medusa3d 3 3 7 p7 nofast primary"
    "medusa3d 4 3 7 p7 nofast asymmetric"
    "aic 3 3 7 p7 nofast primary"
    "aic 4 3 7 p7 nofast asymmetric"
    "groupedaic 3 3 7 p7 nofast primary"
    "groupedaic 4 3 7 p7 nofast asymmetric"
    "groupedxcycle 3 3 7 p7 nofast primary"
    "groupedxcycle 4 3 7 p7 nofast asymmetric"
    "continuousniceloop 3 3 7 p7 nofast primary"
    "continuousniceloop 4 3 7 p7 nofast asymmetric"
    "alsxywing 3 3 7 p7 nofast primary"
    "alsxywing 4 3 7 p7 nofast asymmetric"
    "alschain 3 3 7 p7 nofast primary"
    "alschain 4 3 7 p7 nofast asymmetric"
    "suedecoq 3 3 7 p7 nofast primary"
    "suedecoq 4 3 7 p7 nofast asymmetric"
    "deathblossom 3 3 7 p7 nofast primary"
    "deathblossom 4 3 7 p7 nofast asymmetric"
    "frankenfish 3 3 7 p7 nofast primary"
    "frankenfish 4 3 7 p7 nofast asymmetric"
    "mutantfish 3 3 7 p7 nofast primary"
    "mutantfish 4 3 7 p7 nofast asymmetric"
    "krakenfish 3 3 7 p7 nofast primary"
    "krakenfish 4 3 7 p7 nofast asymmetric"
    "squirmbag 3 3 7 p7 nofast primary"
    "squirmbag 4 3 7 p7 nofast asymmetric"
    "alignedpairexclusion 3 3 7 p7 nofast primary"
    "alignedpairexclusion 4 3 7 p7 nofast asymmetric"
    "alignedtripleexclusion 3 3 7 p7 nofast primary"
    "alignedtripleexclusion 4 3 7 p7 nofast asymmetric"
    "alsaic 3 3 7 p7 nofast primary"
    "alsaic 4 3 7 p7 nofast asymmetric"
    "msls 3 3 8 p8 nofast primary"
    "msls 4 3 8 p8 nofast asymmetric"
    "exocet 3 3 8 p8 nofast primary"
    "exocet 4 3 8 p8 nofast asymmetric"
    "seniorexocet 3 3 8 p8 nofast primary"
    "seniorexocet 4 3 8 p8 nofast asymmetric"
    "skloop 3 3 8 p8 nofast primary"
    "skloop 4 3 8 p8 nofast asymmetric"
    "patternoverlaymethod 3 3 8 p8 nofast primary"
    "patternoverlaymethod 4 3 8 p8 nofast asymmetric"
    "forcingchains 3 3 8 p8 nofast primary"
    "forcingchains 4 3 8 p8 nofast asymmetric"
    "dynamicforcingchains 3 3 8 p8 nofast primary"
    "dynamicforcingchains 4 3 8 p8 nofast asymmetric"
) do (
    call :run_strategy %%~L
    if errorlevel 1 goto cleanup_fail
)

goto cleanup_ok

:cleanup_fail
echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
>> "%SESSION_LOG%" echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
appverif.exe /n "%EXE%" >nul 2>&1
exit /b 1

:cleanup_ok
echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
>> "%SESSION_LOG%" echo [INFO] Resetting AppVerifier for sudoku_gen_test.exe
appverif.exe /n "%EXE%" >nul 2>&1

echo [DONE] Smoke sequence finished.
>> "%SESSION_LOG%" echo [DONE] Smoke sequence finished.
exit /b 0

:run_strategy
set "STRATEGY=%~1"
set "BOX_ROWS=%~2"
set "BOX_COLS=%~3"
set "DIFFICULTY=%~4"
set "MCTS_PROFILE=%~5"
set "FAST_MODE=%~6"
set "VARIANT=%~7"
set "OUTDIR=Debugs\smoke_%STRATEGY%_%VARIANT%"
set "RUNLOG=%REPORT_DIR%\%STRATEGY%_%VARIANT%_raw.txt"

echo.
echo ============================================================================
echo [SMOKE] %STRATEGY% [%VARIANT%] geom=%BOX_ROWS%x%BOX_COLS% difficulty=%DIFFICULTY%
echo ============================================================================
>> "%SESSION_LOG%" echo.
>> "%SESSION_LOG%" echo ============================================================================
>> "%SESSION_LOG%" echo [SMOKE] %STRATEGY% [%VARIANT%] geom=%BOX_ROWS%x%BOX_COLS% difficulty=%DIFFICULTY%
>> "%SESSION_LOG%" echo ============================================================================

if /I "%FAST_MODE%"=="nofast" (
    "%EXE%" --cli --box-rows %BOX_ROWS% --box-cols %BOX_COLS% --difficulty %DIFFICULTY% --required-strategy %STRATEGY% --seed 0 --target 5 --threads 12 --max-total-time-s %MAX_TOTAL_TIME% --max-attempts %MAX_ATTEMPTS% --mcts-profile %MCTS_PROFILE% --output-folder "%OUTDIR%" --output-file generated_sudoku.txt --single-file-only --benchmark-mode --pattern-forcing --strict-canonical-strategies --no-proxy-advanced --no-fast-test > "%RUNLOG%" 2>&1
) else (
    "%EXE%" --cli --box-rows %BOX_ROWS% --box-cols %BOX_COLS% --difficulty %DIFFICULTY% --required-strategy %STRATEGY% --seed 0 --target 5 --threads 12 --max-total-time-s %MAX_TOTAL_TIME% --max-attempts %MAX_ATTEMPTS% --mcts-profile %MCTS_PROFILE% --output-folder "%OUTDIR%" --output-file generated_sudoku.txt --single-file-only --benchmark-mode --pattern-forcing --strict-canonical-strategies --no-proxy-advanced --fast-test > "%RUNLOG%" 2>&1
)
set "RUN_EXIT=%ERRORLEVEL%"
type "%RUNLOG%"
type "%RUNLOG%" >> "%SESSION_LOG%"
if not "%RUN_EXIT%"=="0" (
    echo [ERROR] Strategy failed: %STRATEGY% [%VARIANT%]
    >> "%SESSION_LOG%" echo [ERROR] Strategy failed: %STRATEGY% [%VARIANT%]
    goto cleanup_fail
)

goto :eof
